<?php
    include('../configure/config.php');
    include('login_check.php');
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="admin.css"> 
    <title>Comida</title>
</head>
<body>
    <!--menu starts-->
    <div class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
                    <img src="../img/logo1.jpg" alt="Restaurant Logo" class="img-responsive">
                </a>
            </div>
            <div class = "wrapper1">
                <ul class = "menu">
                    <li><a href = "index.php">Home</a>
                    <li><a href = "category.php">Category</a>
                    <li><a href = "food.php">Food</a>
                    <li><a href = "order.php">Order</a>
                    <li><a href = "manage.php">Admin</a>
                    <li><a href = "logout.php">Logout</a>
                </ul>

            </div>
        </div>
    </div>
    
    <!--menu ends-->