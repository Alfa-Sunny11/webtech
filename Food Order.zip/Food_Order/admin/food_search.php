<?php
    include('inside/menu.php');
    
echo "worked";


    include('inside/footer.php');
?> 