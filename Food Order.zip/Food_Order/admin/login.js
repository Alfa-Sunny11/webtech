function validate(){
      var username = document.getElementById("username").nodeValue;
      var password = document.getElementById("password").nodeValue;
      if(username !="" || password != ""){
            alert("Login Successfully");
            return true;
      }
      else{
            alert("Type your username & password correctly");
            return false;
      }
}