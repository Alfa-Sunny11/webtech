<?php
    include('inside/menu.php');
?>
<div>
    <div class = "wrapper">
        <h1>Order</h1>

            <table class = "tbl">
                <tr>
                    <th>S.N.</th>
                    <th>Food</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>total</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Customer name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>

                
            </table> 
    </div>    
</div>
<?php
    include('inside/footer.php');
?>