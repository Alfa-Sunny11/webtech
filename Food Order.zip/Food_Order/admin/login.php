<?php
    include('../configure/config.php');
?>

<html>
   <head>
   <link rel="stylesheet" href="style1.css">
   <script src="login.js"></script>
   <title>Login - Food Order System</title>
   </head>

   <body>
      <div>
            
            <?php
                if(isset($_SESSION['login'])){
                    echo $_SESSION['login'];
                    unset($_SESSION['login']);
                }

                if(isset($_SESSION['no_login_msg'])){
                  echo $_SESSION['no_login_msg'];
                  unset($_SESSION['no_login_msg']);
              }
            ?> <br>   

            <form  class = "box" active = "" method = "POST">
            <h1>Login</h1><br><br>
                  
                  <input type ="text" name = "uname" placeholder = "Enter your username" id="username"><br><br>
                  
                  
                  <input type ="password" name = "password" placeholder = "Enter Password" id="password"><br><br>
                  
                  <input type ="submit" name = "submit" value = "login" onclick="return validate()">
            </form>
            
      </div>
   </body>
</html>

<?php
      if(isset($_POST['submit'])){
            $uname = $_POST['uname'];
            $password = md5($_POST['password']);

            $sql = "SELECT * FROM admin WHERE uname='$uname' AND password = '$password'";

            $res = mysqli_query($conn, $sql);

            $count = mysqli_num_rows($res);
            if($count == 1){
                  $_SESSION['login'] = "Login Successfully";
                  $_SESSION['user'] = $uname;
                  header("location:".SITEURL.'admin/');
              }
              else{
                  $_SESSION['login'] = "Username or Password didn't match";
                  header("location:".SITEURL.'admin/login.php');
              }
      }
?>