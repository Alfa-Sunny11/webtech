<?php
    include('configure/config.php')

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"> 
    <title>Comida</title>
</head>
<body>
    <!--menu starts-->
    <div>
        <div class = "wrapper">
            <ul class = "menu">
                <li><a href = "<?php echo SITEURL; ?>">Home</a>
                <li><a href = "<?php echo SITEURL; ?>categories.php">Category</a>
                <li><a href = "<?php echo SITEURL; ?>foods.php">Food</a>
                <li><a href = "<?php echo SITEURL; ?>order.php">Order</a>
                <li><a href = "<?php echo SITEURL; ?>contact.php">Contact</a>
            </ul>
            


        </div>

    </div>
    <!--menu ends-->