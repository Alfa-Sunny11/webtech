    <!--footer starts-->
    <div class = "wrapper">
         <footer>
            <p>
                Copyright &copy 2021 Comida Developed By - <a href = "#">Group 3</a>
            <p>
        </footer>
    </div>
    <!--footer ends-->
</body>
</html>